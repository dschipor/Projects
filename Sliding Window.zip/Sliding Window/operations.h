#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "link_emulator/lib.h"
#ifndef FIXED_LEN
#define FIXED_LEN 1400
#endif
#ifndef MAX_LEN
#define MAX_LEN 1399
#endif
#ifndef DATA_LEN
#define DATA_LEN 1395
#endif
#ifndef OFFSET
#define OFFSET (sizeof(char) + sizeof(int))
#endif



int max(const int a, const int b){
  if(a > b){
    return a;
  }
  return b;
}

int min(const int a, const int b){
  if(a < b){
    return a;
  }
  return b;
}

int compare(char *source, char *destination, int len){
  for(int i = 0; i < len; i++){
    if(source[i] != destination[i]){
      return 0;
    }
  }
  return 1;
}

char* check(char *response){
  if(compare(response, "ACK", 3)){
    return "ACK";
  }
  return "NACK";
}

//returns CRC for string data
int checkSum(char *data, int len){
  int res = 0;
  for(int i = 0; i < len; i++){
    res ^= data[i];
  }
  return res;
}

void makePayload(char destination[FIXED_LEN], char *data, const int number, const int dataLen){
  memcpy(destination + 1, &number, sizeof(int));
  memcpy(destination + 1 + sizeof(int), data, dataLen);
  
  char CRC = (char) checkSum(destination + 1, dataLen + sizeof(int));
  destination[0] = CRC;
}

void unpackPayload (char source[FIXED_LEN], const int dataLen, int *number, char *sndCRC, char *recvCRC){
  memcpy(sndCRC, source, 1);
  memcpy(number, source + 1, sizeof(int));
  (*recvCRC) = (char) checkSum(source + 1, sizeof(int) + dataLen);
}

struct QNode{
  int key;
  struct QNode *next;
};

struct Queue{
  struct QNode *front, *rear;
};

struct QNode* newNode(int key){
  struct QNode * item = (struct QNode *)malloc(sizeof(struct QNode));
  item->key = key;
  item->next = NULL;
  return item;
}

int isEmpty(struct Queue* q){
  if(q->front == NULL){
    return 1;
  }
  return 0;
}

struct Queue *createQueue(){
  struct Queue *q = (struct Queue *) malloc(sizeof(struct Queue));
  q->front = q->rear = NULL;
  return q;
}

int top(struct Queue *q){
  if(!isEmpty(q)){
    return (((struct QNode*)q->front)->key);
  }
  printf("Warning! Called top on empty queue!\n");
  return -1;
}

void printQueue(struct Queue *q, char *name){
  struct QNode* current = q->front;
  printf("\nQueue %s is:", name);
  while(current != NULL){
    int key = current->key;
    printf("%d ", key);
    current = current->next;
  }
  printf("\n");
}

int getSize(struct Queue *q){
  int res = 0;
  struct QNode *current = q->front;
  while(current != NULL){
    res++;
    current = current->next;
  }
  return res;
}

int getElement(struct Queue *q, int index){
  int res = -1, count = 0;
  struct QNode *current = q->front;
  while(current != NULL){
    count++;
    if(index == count){
      return current->key;
    }
    current = current->next;
  }
  return res;
}

void enqueue(struct Queue *q, int key){
  struct QNode *item = newNode(key);
  if(q->rear == NULL){
    q->front = item; 
    q->rear = item; return;
  }

  ((struct QNode *)q->rear)->next = item;
  q->rear = item;
}

int dequeue(struct Queue *q){
  if(q->front == NULL){
    return 0;
  }
  q->front = ((struct QNode *) q->front)->next;
  if(q->front == NULL){
    q->rear = NULL;
  }
  return 1;
}

int removeElement(struct Queue *q, int key){
  if(q->front == NULL){
    printf("Warning! Called removeElement on empty queue!\n");
    return 0;
  }
  struct QNode* current = q->front;
  if(current->key == key){
    dequeue(q); return 1;
  }
  current = current->next;
  struct QNode* previous = q->front;
  while(current != NULL){
    if(current->key == key){
      if(current == q->rear){
        previous->next = NULL; q->rear = previous;
        return 1;
      }
      else{
        previous->next = current->next; return 1;
      }
    }
    current = current->next; previous = previous->next;
  }
  return 0;
}
