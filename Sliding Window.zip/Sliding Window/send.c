#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "link_emulator/lib.h"
#include "operations.h"

#define HOST "127.0.0.1"
#define PORT 10000
#ifndef FIXED_LEN
#define FIXED_LEN 1400
#endif
#ifndef MAX_LEN
#define MAX_LEN 1399
#endif
#ifndef DATA_LEN
#define DATA_LEN 1395
#endif
#ifndef OFFSET
#define OFFSET (sizeof(char) + sizeof(int))
#endif
#ifndef MAX_FRAME_NUMBER
#define MAX_FRAME_NUMBER 2000
#endif
#ifndef WAIT_TIME
#define WAIT_TIME 1.5
#endif

int main(int argc,char** argv){
  init(HOST,PORT);
  msg t;
  char buf[DATA_LEN];

  int speed = atoi(argv[2]), delay = atoi(argv[3]); int wait_time = WAIT_TIME * delay;
  int bdp = speed * delay;
  int window = (bdp * 1000) / (sizeof(msg) * 8);

  //printf("[SENDER]: Link data: BDP = %d, WINDOW = %d\n", bdp, window);

  char *inputFile = argv[1];
  int fin = open(inputFile, O_RDONLY);
  int fileSize = lseek(fin, 0, SEEK_END) - lseek(fin, 0, SEEK_SET);
  lseek(fin, 0, SEEK_SET);
  int frameNumber = fileSize / DATA_LEN; frameNumber = max(frameNumber + 1, 1);

  char outputFile[20] = "recv_";
  strncat(outputFile, inputFile, strlen(inputFile));

  /**
   * SEND THE NAME OF THE FILE
   */

  int ok = 0;
  do{
    int nameLen = strlen(outputFile);
    makePayload(t.payload, outputFile, frameNumber, nameLen); t.len = nameLen;
    send_message(&t);
    if(recv_message_timeout(&t, wait_time) < 0){
      //printf("[SENDER] FILENAME frame lost! Sending again...\n");
      makePayload(t.payload, outputFile, frameNumber, nameLen); t.len = nameLen;
      send_message(&t);
    }
    //printf("[SENDER] Received %s for frame %s\n", check(t.payload + OFFSET), "FILENAME");
    if(compare(t.payload + OFFSET,"ACK", t.len)){
      ok = 1;
    }  
  }while(!ok);
  
  /**
   * MAKE ALL FRAMES TO BE SENT
   */

  msg frames[MAX_FRAME_NUMBER];
  for(int frameID = 1; frameID <=frameNumber; frameID++){
    int dataLen = read(fin, buf, DATA_LEN); char *data = buf; int number = frameID;
    makePayload(frames[frameID].payload, data, number, dataLen); frames[frameID].len = dataLen;
  }
  
  /**
   * SEND THE FIRST SLIDING WINDOW
   */

  int windowSize = min(window, frameNumber);
  struct Queue *slidingWindow = createQueue();
  for(int frameID = 1; frameID <= windowSize; frameID++){
    enqueue(slidingWindow, frameID);
    send_message(&frames[frameID]);
  }
  //printf("\n\n #### FIRST SLIDING WINDOW SENT ####\n\n\n");
  
  /**
   * KEEP SENDING AND UPDATING THE SLIDING WINDOW
   */

  for(int frameID = windowSize + 1; frameID <= frameNumber; ){
    if(recv_message_timeout(&t, wait_time / 5) < 0){
      //printf("[SENDER] Frame lost! Sending top frame again...\n");
      send_message(&frames[top(slidingWindow)]);
      continue;
    }
    int *rcvNumber = (int *)(t.payload + 1); int ID = (*rcvNumber); 
    char ack[10]; strcpy(ack, check(t.payload + OFFSET)); 
    //printf("[SENDER] Received %s for frame #%d\n", ack, ID); 
    if(strcmp(ack, "ACK") == 0){
      if(removeElement(slidingWindow, ID)){
      enqueue(slidingWindow, frameID); send_message(&frames[frameID]);
      frameID++;
      }
      else{
        //printf("[SENDER] Already received %s for frame #%d\n", ack, ID);
        if(!isEmpty(slidingWindow)){
          send_message(&frames[top(slidingWindow)]);
        }
      }
    }
    else{
      send_message(&frames[top(slidingWindow)]);
    }
  }
  //printf("\n\n #### SEND THE LAST SLIDING WINDOW ####\n\n\n");

  /**
   * SEND THE LAST SLIDING WINDOW
   */

  for(int frameID; frameID <= windowSize; frameID++){
      int ID = getElement(slidingWindow, frameID);
      send_message(&frames[ID]);    
  }
  while(!isEmpty(slidingWindow)){
    //printQueue(slidingWindow, "slidingWindow");
    if(recv_message_timeout(&t, wait_time) < 0){
      //printf("[SENDER] Frame lost! Sending top frame again...\n");
      send_message(&frames[top(slidingWindow)]);
      continue;
    }
    int *rcvNumber = (int *)(t.payload + 1); int ID = (*rcvNumber); 
    char ack[10]; strcpy(ack, check(t.payload + OFFSET));
    //printf("[SENDER] Received %s for frame #%d\n", ack, ID);
    if(strcmp(ack, "ACK") == 0){
      if(removeElement(slidingWindow, ID)){
        //printf("[SENDER] Disposed of frame #%d from sliding window\n", ID);
      }
      else{
        //printf("[SENDER] Already received %s for frame #%d\n", ack, ID);
        send_message(&frames[top(slidingWindow)]);
      }
    }
    else{
      //printf("TOP #%d of stackWindow not sent\n", top(slidingWindow));
      if(!isEmpty(slidingWindow)){
        send_message(&frames[top(slidingWindow)]);
      }
    }
  }
  //printf("[SENDER] All operations completed! Well done!\n");
  
  /**
   * SEND THE END FRAME
   */
  
  ok = 0;
  do{
    makePayload(t.payload, "!ALL DONE!", 0, 11); t.len = -15; send_message(&t);
    
    if(recv_message_timeout(&t, wait_time) < 0){
      ok = 0;
      continue;
    }
    char ack[10]; strcpy(ack, check(t.payload + OFFSET));
    if(t.len == -15){
      ok = 1;
    }
  }while(!ok);
  recv_message(&t);
  //printf("[SENDER] Exits!\n");
  return 0;
}
