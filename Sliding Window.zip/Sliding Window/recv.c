#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "link_emulator/lib.h"
#include "operations.h"

#define HOST "127.0.0.1"
#define PORT 10001
#ifndef FIXED_LEN
#define FIXED_LEN 1400
#endif
#ifndef MAX_LEN
#define MAX_LEN 1399
#endif
#ifndef DATA_LEN
#define DATA_LEN 1395
#endif
#ifndef OFFSET
#define OFFSET (sizeof(char) + sizeof(int))
#endif
#ifndef MAX_FRAME_NUMBER
#define MAX_FRAME_NUMBER 2000
#endif

int main(int argc,char** argv){
  msg r;
  init(HOST,PORT);
  int frameNumber = 0;
  char outputName[50] = "";
  int fout;

  /**
   * RECEIVE THE NAME OF THE FILE
   */

  int ok = 0;
  do{
    if(recv_message(&r) < 0){
      //printf("[RECEIVER] Frame lost! Waiting for another frame...\n");
      continue;
    }
    char sndCRC, rcvCRC; int number; unpackPayload(r.payload, r.len, &number, &sndCRC, &rcvCRC); 
    //printf("[RECEIVER] Received frame %s | sndCRC = %d and rcvCRC = %d\n", r.payload + OFFSET, sndCRC, rcvCRC);
    if(sndCRC == rcvCRC){
      ok = 1;
      memcpy(outputName, r.payload + OFFSET, r.len); outputName[r.len + 1] = '\0';
      frameNumber = number;
      makePayload(r.payload, "ACK", 0, 4); r.len = 3;
    }
    else{
      makePayload(r.payload, "NACK", 0, 5); r.len = 4;
    }
    send_message(&r);
  }while(!ok);
  
  //printf("[RECEIVER] Is ready to write %d files in %s\n", frameNumber, outputName);
  fout = open(outputName, O_WRONLY | O_CREAT, 0644);
  msg frames[MAX_FRAME_NUMBER];
  
  /**
   * CREATE SPACE FOR FRAMES TO BE COLLECTED
   */

  for(int frameID = 1; frameID <= frameNumber; frameID++){
    frames[frameID].len = -1;
  }
  
  /**
   * RECEIVE FRAMES UNTIL END FRAME
   */

  ok = 0;
  do{
    if(recv_message(&r) < 0){
      //printf("[RECEIVER] Frame lost! Waiting for another frame...\n");
      continue;
    }
    char sndCRC, rcvCRC; int number; unpackPayload(r.payload, r.len, &number, &sndCRC, &rcvCRC);
    //printf("[RECEIVER] Received frame #%d | sndCRC = %d and rcvCRC = %d\n", number, sndCRC, rcvCRC);
    if(r.len == -15){
      ok = 1;
      makePayload(r.payload, "ACK", 0, 4); r.len = -15;
      send_message(&r);
      continue;
    }
    if(sndCRC == rcvCRC){
      memcpy(&frames[number], &r, sizeof(msg));
      makePayload(r.payload, "ACK", number, 4); r.len = 3;
    }
    else{
       makePayload(r.payload, "NACK", number, 5); r.len = 4;
    }
    send_message(&r);
  }while(!ok);
  
  /**
   * WRITE OUTPUT FILE
   */
  
  for(int frameID = 1; frameID <= frameNumber; frameID++){
    if(frames[frameID].len > 0){
      write(fout, frames[frameID].payload + OFFSET, frames[frameID].len);
    }
    else{
      //printf("[RECEIVER] Frame #%d is missing!\n", frameID);
    }
  }
  //printf("[RECEIVER] All operations completed! Well done!\n");
  send_message(&r); //needed to make diff work
  //printf("[RECEIVER] Exits!\n");
  return 0;
}
