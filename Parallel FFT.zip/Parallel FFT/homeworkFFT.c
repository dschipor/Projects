
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <pthread.h>
#include <string.h>
#define BIGP 5

double PI;
int N, P;
typedef double complex cplx;
cplx *BUF;
cplx *RES;
pthread_t tid[BIGP];
int thread_id[BIGP];
struct threadInfo
{
	cplx *buf;
	cplx *res;
	int step;
	int id;
} threadInfo;

void printOutput(FILE *out, cplx res[], int n)
{
	fprintf(out, "%d\n", n);
	for (int i = 0; i < n; i++)
	{
		fprintf(out, "%lf %lf\n", creal(res[i]), cimag(res[i]));
	}
}

/**
 * fftFunction: while the size of step still permits distributing the task
 * to other threads (step < P), create a new thread to deal with the right side
 * of the execution three. When step > P, continue with sequential FFT.
 * 
 * Because of the independence between the left side and the right side of the execution tree,
 * the chances of there being critical zones are nonexistent. That being the case, the
 * execution on threads can go uninterrupted. 
 */


void *fftFunction(void *args)
{
	struct threadInfo ti = *(struct threadInfo *)args;
	int id = ti.id;
	int step = ti.step;
	cplx *buf = ti.buf;
	cplx *res = ti.res;

	struct threadInfo rightInfo;
	rightInfo.buf = res + step;
	rightInfo.res = buf + step;
	rightInfo.step = step * 2;

	if (step < N)
	{
		if (step < P)
		{
			rightInfo.id = id + P / (step * 2);
			pthread_create(&(tid[rightInfo.id]), NULL, fftFunction, &rightInfo);
		}
		else
		{
			rightInfo.id = id;
			fftFunction(&rightInfo);
		}

		struct threadInfo newti;
		newti.id = id;
		newti.buf = res;
		newti.res = buf;
		newti.step = 2 * step;
		fftFunction(&newti);

		if (step < P)
		{
			pthread_join(tid[rightInfo.id], NULL);
		}

		for (int i = 0; i < N; i += 2 * step)
		{
			cplx t = cexp(-I * PI * i / N) * res[i + step];
			buf[i / 2] = res[i] + t;
			buf[(i + N) / 2] = res[i] - t;
		}
	}
}

void parseInput(FILE *in)
{
	int ok;
	ok = fscanf(in, "%d", &N);

	if (ok)
	{
		BUF = (cplx *)malloc(N * sizeof(cplx));
		RES = (cplx *)malloc(N * sizeof(cplx));

		for (int i = 0; i < N; i++)
		{
			double real;
			ok = fscanf(in, "%lf", &real);
			RES[i] = BUF[i] = real + 0 * I;
		}
	}
}

int main(int argc, char *argv[])
{
	/**
	 *	First step: prepare I/O 
	*/
	PI = atan2(1, 1) * 4;
	char *inputName = argv[1];
	char *outputName = argv[2];
	P = atoi(argv[3]);
	FILE *in = fopen(inputName, "r");
	FILE *out = fopen(outputName, "w");
	parseInput(in);

	/**
	 *	Second step: threads setup
	 */
	struct threadInfo startInfo;
	startInfo.buf = BUF;
	startInfo.res = RES;
	startInfo.step = 1;
	startInfo.id = 0;

	pthread_create(&(tid[0]), NULL, fftFunction, &startInfo);
	pthread_join(tid[0], NULL);

	/**
	 * Third step: print output
	 */
	printOutput(out, BUF, N);

	/**
	 * Fourth step: free memory
	 */
	free(BUF);
	free(RES);
	fclose(in);
	fclose(out);

	return 0;
}