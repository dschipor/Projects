#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <pthread.h>
#include <string.h>

double PI;
int N, P;
typedef double complex cplx;
cplx *BUF;
cplx *RES;


void *ftFunction(void *args){
	int threadId = *(int *)args;
	int size = N / P;
	int remainder = N % P;
	int start = 0, end = 0;

	if(remainder && threadId < remainder){
		size++;
		start += threadId * size;
	}
	else{
		start = threadId * size + remainder;
	}
	end = start + size;

	for(int k = start; k < end; k++){
		double sumreal = 0;
		double sumimg = 0;
		for(int i = 0; i < N; i++){
			double angle = 2 * PI * i * k / N;
			sumreal += creal(BUF[i]) * cos(angle) + cimag(BUF[i]) * sin(angle);
			sumimg += (-1) * creal(BUF[i]) * sin(angle) + cimag(BUF[i]) * cos(angle); 
		}
		RES[k] += (sumreal + sumimg * I);
	} 
}

void parseInput(FILE *in){
	int ok;
	ok = fscanf(in, "%d", &N);
	
	if(ok){
		BUF = (cplx *)calloc(N, sizeof (cplx));
		RES = (cplx *)calloc(N, sizeof (cplx));
	
		for(int i = 0; i < N; i++){
			double real;
			ok = fscanf(in, "%lf", &real);
			BUF[i] = real + 0 * I;
		}
	}
	
}

void printOutput(FILE *out, cplx res[], int n){
	fprintf(out, "%d\n", n);
	for(int i = 0; i < n; i++){		
		fprintf(out,"%lf %lf\n", creal(res[i]), cimag(res[i]));
	}
}

int main(int argc, char * argv[]) {
	/**
	 *	First step: prepare I/O 
	*/
	PI = atan2(1, 1) * 4;
	char *inputName = argv[1];
	char *outputName = argv[2];
	P = atoi(argv[3]);
	FILE *in = fopen(inputName, "rt");
	FILE *out = fopen(outputName, "wt");
	parseInput(in);
	
	/**
	 *	Second step: setup threads 
	 */
	pthread_t tid[P];
	int thread_id[P];
	for(int i = 0; i < P; i++)
		thread_id[i] = i;
	
	for(int i = 0; i < P; i++) {
		pthread_create(&(tid[i]), NULL, ftFunction, &(thread_id[i]));
	}
	for(int i = 0; i < P; i++) {
		pthread_join(tid[i], NULL);
	}
	
	/**
	 * Third step: print output
	 */
	printOutput(out, RES, N); 

	/**
	 * Fourth step: free memory
	 */
	free(BUF);
	free(RES);
	fclose(in);
	fclose(out);

	return 0;
}
