#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

float conv(unsigned char a[3][3], float b[3][3])
{
    float res = 0;
    for (int i = 2; i >= 0; i--)
    {
        for (int j = 2; j >= 0; j--)
        {
            res += (float)a[i][j] * b[2 - i][2 - j];
        }
    }
    return res;
}

void copyFilter(float a[3][3], float b[3][3])
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            b[i][j] = a[i][j];
        }
    }
}

//init for filters
float smoothing[3][3] = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
float blur[3][3] = {{1, 2, 1}, {2, 4, 2}, {1, 2, 1}};
float sharpen[3][3] = {{0, -2, 0}, {-2, 11, -2}, {0, -2, 0}};
float removal[3][3] = {{-1, -1, -1}, {-1, 9, -1}, {-1, -1, -1}};
float emboss[3][3] = {{0, 1, 0}, {0, 0, 0}, {0, -1, 0}};
float filter[3][3];

FILE *in;
char *inputName;
FILE *out;
char *outputName;
unsigned char *imageBW; unsigned char *imageBW_copy;
unsigned char *imageR; unsigned char *imageR_copy;
unsigned char *imageG; unsigned char *imageG_copy;
unsigned char *imageB; unsigned char *imageB_copy;

char comment[200];
char type[3];
int height, width;
float maxValue = 0;
int pixelSize = 1;

unsigned char dummy[3][3];

//functions for debugging
void _debugImage(char *message, unsigned char *img)
{
    printf("\n%s", message);
    for(int i = 0; i < height * width; i++){
        if(i % width == 0) printf("\n");
        printf("%.3f ", (float)img[i]);
    }
    printf("\n\n");
}

void _debugMat(char *message, float mat[3][3]){
    printf("\n%s\n", message);
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            printf("%.2f ", (float)mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void _debugMatUC(char *message, unsigned char mat[3][3]){
    printf("\n%s\n", message);
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            printf("%.2f ", (float)mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

//cast float to UC, using maxValue
char castToUC(float value)
{
    float minValue = 0;
    if (value > maxValue)
    {
        return (char)maxValue;
    }
    else if(value < minValue)
    {
        return (char)minValue;
    }
    else
    {
        return (char)value;
    }
}

void init()
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            smoothing[i][j] /= 9;
            blur[i][j] /= 16;
            sharpen[i][j] /= 3;
        }
    }
}

void parseInput()
{
    in = fopen(inputName, "rb");
    char newline; //for skipping over \n when reading with fgets

    if (in == NULL)
    {
        printf("ERROR reading image!");
    }

    //check if pixel has size 1 or 3
    fgets(type, 3, in);
    fscanf(in, "%c", &newline);
    if (!strcmp(type, "P6"))
    {
        pixelSize = 3;
        printf("%s\n", type);
    }

    //skip the line of comments
    fgets(comment, 200, in);
    printf("%s", comment);

    //get width and height
    fscanf(in, "%d %d", &width, &height);
    fscanf(in, "%c", &newline);
    printf("%d %d\n", width, height);

    //get maxValue
    fscanf(in, "%f", &maxValue);
    printf("%.0f\n", maxValue);
    fscanf(in, "%c", &newline);
    //write image into buffer
    if (pixelSize == 1)
    {
        imageBW = (unsigned char *)calloc(height * width, sizeof(unsigned char)); 
        for (int i = 0; i < height * width; i++)
        {
            fscanf(in, "%c", &imageBW[i]);     
        }

        // _debugImage("input image:", imageBW);
    }

    if (pixelSize == 3)
    {
        imageR = (unsigned char *)calloc(height * width, sizeof(unsigned char)); 
        imageG = (unsigned char *)calloc(height * width, sizeof(unsigned char)); 
        imageB = (unsigned char *)calloc(height * width, sizeof(unsigned char)); 
        for (int i = 0; i < height * width; i++)
        {
            fscanf(in, "%c", &imageR[i]);
            fscanf(in, "%c", &imageG[i]);
            fscanf(in, "%c", &imageB[i]);
        }
    }
    fclose(in);
}

void writeOutput()
{
    out = fopen(outputName, "wb");

    if (out == NULL)
    {
        printf("ERR writing image");
    }

    fprintf(out, "%s\n", type);
    fprintf(out, "%s", comment);
    fprintf(out, "%d %d\n", width, height);
    fprintf(out, "%.0f\n", maxValue);

    if (pixelSize == 1)
    {
        for (int i = 0; i < height * width; i++)
        {
            fprintf(out, "%c", imageBW_copy[i]);
        }

        //_debugImage("image_out:", imageBW_copy);
    }
    if (pixelSize == 3)
    {
        for (int i = 0; i < height * width; i++)
        {
            fprintf(out, "%c", imageR_copy[i]);
            fprintf(out, "%c", imageG_copy[i]);
            fprintf(out, "%c", imageB_copy[i]);
        }
    }
    fclose(out);
}

int getCenterI(int number)
{
    return (number / (width));
}
int getCenterJ(int number)
{
    return (number % (width));
}

//prepare input matrix for convolution around center
void prepareInput(unsigned char *channel, int centeri, int centerj)
{
    //use upper left corner as reference as it's easier to calculate
    int corneri = centeri - 1;
    int cornerj = centerj - 1;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            int y = corneri + i;
            int x = cornerj + j;
            if (y < 0 || x < 0 || y >= height || x >= width)
            {
                dummy[i][j] = 0;
            }
            else
            {
                dummy[i][j] = channel[y * width + x];
            }
        }
    }
}

int main(int argc, char **argv)
{
    int rank, proc;

    // init for processes
    MPI_Init(&argc, &argv);

    //assign rank for each proc
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); // rank
    //set number of proc
    MPI_Comm_size(MPI_COMM_WORLD, &proc);

    init();
    //parse the input image
    inputName = argv[1];
    outputName = argv[2];

    //parse the image and send general purpose info to all processes
    if (rank == 0)
    {
        //parse image
        parseInput();

        //send general purpose info to other proc
        MPI_Bcast(&pixelSize, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&height, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&width, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&maxValue, 1, MPI_INT, 0, MPI_COMM_WORLD);
    }
    else
    {
        //receive general purpose inf from root
        MPI_Bcast(&pixelSize, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&height, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&width, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&maxValue, 1, MPI_INT, 0, MPI_COMM_WORLD);

        //init image as the calloc from parsing wasn't made in these processes
        if (pixelSize == 1)
        {
            imageBW = (unsigned char *)calloc(height * width, sizeof(unsigned char));
        }

        if (pixelSize == 3)
        {
            imageR = (unsigned char *)calloc(height * width, sizeof(unsigned char));

            imageG = (unsigned char *)calloc(height * width, sizeof(unsigned char));

            imageB = (unsigned char *)calloc(height * width, sizeof(unsigned char));
        }
    }

    //alloc memory for the copy of the images
    if(pixelSize == 1)
    {
        imageBW_copy = (unsigned char *)calloc(height * width, sizeof(unsigned char));
    }
    if(pixelSize == 3)
    {
        imageR_copy = (unsigned char *)calloc(height * width, sizeof(unsigned char));
        imageG_copy = (unsigned char *)calloc(height * width, sizeof(unsigned char));
        imageB_copy = (unsigned char *)calloc(height * width, sizeof(unsigned char));
    }
    
    //do the conv tasks for each process, then send the results to root
    for (int fcount = 3; fcount < argc; fcount++)
    {
        char *filterName = argv[fcount];

        if (pixelSize == 1)
            MPI_Bcast(imageBW, height * width, MPI_CHAR, 0, MPI_COMM_WORLD);
        if (pixelSize == 3)
        {
            MPI_Bcast(imageR, height * width, MPI_CHAR, 0, MPI_COMM_WORLD);
            MPI_Bcast(imageG, height * width, MPI_CHAR, 0, MPI_COMM_WORLD);
            MPI_Bcast(imageB, height * width, MPI_CHAR, 0, MPI_COMM_WORLD);
        }

        //determine the filter
        if (!strcmp(filterName, "smoothing"))
            copyFilter(smoothing, filter);
        else if (!strcmp(filterName, "blur"))
            copyFilter(blur, filter);
        else if (!strcmp(filterName, "sharpen"))
            copyFilter(sharpen, filter);
        else if (!strcmp(filterName, "removal"))
            copyFilter(removal, filter);
        else if (!strcmp(filterName, "emboss"))
            copyFilter(emboss, filter);
        else
        {
            printf("USAGE: tema3 input output filters(smoothing/blur/sharpen/removal/emboss)\n");
            break;
        }
            
        //do the task
        if (rank == 0)
        {
            //generate individual values for rank 0
            int imgSize = height * width;
            int remainder = imgSize % proc;
            int taskSize = (imgSize / proc);
            int maxTaskSize = (imgSize / proc) + 1;
            int start = 0;

            //printf("rank=%d\timgSize=%d\tremainder=%d\ttaskSize=%d\tmaxTaskSize=%d\tstart=%d\n", rank, imgSize, remainder, taskSize, maxTaskSize, start);

            if (remainder != 0)
                taskSize++;

            //do the rank 0 task
            for (int i = 0; i < taskSize; i++)
            {
                //prepare pixel and dummy matrix
                int currentValue = i + start;
                int centerI = getCenterI(currentValue);
                int centerJ = getCenterJ(currentValue);

                if (pixelSize == 1)
                {
                    prepareInput(imageBW, centerI, centerJ);
                    imageBW_copy[currentValue] = castToUC(conv(dummy, filter));

                    // if(centerI == 1 && centerJ == 4)
                    // {
                    //     _debugMatUC("dummy:", dummy);
                    //     _debugMat("filter:", filter);

                    //     printf("conv result is %f:\n", conv(dummy, filter));
                    //     printf("casted conv result is %f:\n", (float)castToUC(conv(dummy, filter)));

                    // }
                    
                    char message[100]; sprintf(message, "image after task %d:", i);
                    // _debugImage(message, imageBW_copy);
                }

                if (pixelSize == 3)
                {
                    prepareInput(imageR, centerI, centerJ);
                    imageR_copy[currentValue] = castToUC(conv(dummy, filter));

                    prepareInput(imageG, centerI, centerJ);
                    imageG_copy[currentValue] = castToUC(conv(dummy, filter));

                    prepareInput(imageB, centerI, centerJ);
                    imageB_copy[currentValue] = castToUC(conv(dummy, filter));
                }
            }
            //receive task results from others
            for (int i = 1; i < proc; i++)
            {
                //calculate task values for proc i
                int taskSize = (imgSize / proc);
                if (i < remainder)
                {
                    taskSize++;
                    start = i * taskSize;
                }
                else
                {
                    start = i * taskSize + remainder;
                }

                //receive results from proc i
                if (pixelSize == 1)
                {
                    MPI_Recv(imageBW_copy + start, taskSize, MPI_CHAR, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }

                if (pixelSize == 3)
                {
                    MPI_Recv(imageR_copy + start, taskSize, MPI_CHAR, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Recv(imageG_copy + start, taskSize, MPI_CHAR, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                    MPI_Recv(imageB_copy + start, taskSize, MPI_CHAR, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                }
            }

            //update root image for next filter
            if(pixelSize == 1)
            {
                memcpy(imageBW, imageBW_copy, height * width);
            }
            if(pixelSize == 3)
            {
                memcpy(imageR, imageR_copy, height * width);
                memcpy(imageG, imageG_copy, height * width);
                memcpy(imageB, imageB_copy, height * width);
            }
        }
        else
        {
            //generate individual task numbers for rank
            int imgSize = height * width;
            int remainder = imgSize % proc;
            int taskSize = (imgSize / proc);
            int start = 0;

            if (rank < remainder)
            {
                taskSize++;
                start = rank * taskSize;
            }
            else
            {
                start = rank * taskSize + remainder;
            }

            //printf("rank=%d\timgSize=%d\tremainder=%d\ttaskSize=%d\tstart=%d\n", rank, imgSize, remainder, taskSize, start);

            //do the task
            
            for (int i = 0; i < taskSize; i++)
            {
                //prepare pixel and dummy matrix
                int currentValue = i + start;
                int centerI = getCenterI(currentValue);
                int centerJ = getCenterJ(currentValue);

                

                if (pixelSize == 1)
                {
                    prepareInput(imageBW, centerI, centerJ);
                    imageBW_copy[currentValue] = castToUC(conv(dummy, filter));
                }

                if (pixelSize == 3)
                {
                    prepareInput(imageR, centerI, centerJ);
                    imageR_copy[currentValue] = castToUC(conv(dummy, filter));

                    prepareInput(imageG, centerI, centerJ);
                    imageG_copy[currentValue] = castToUC(conv(dummy, filter));

                    prepareInput(imageB, centerI, centerJ);
                    imageB_copy[currentValue] = castToUC(conv(dummy, filter));
                }
            }

            //send results to root
            if (pixelSize == 1)
            {
                MPI_Send(imageBW_copy + start, taskSize, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
            }

            if (pixelSize == 3)
            {
                MPI_Send(imageR_copy + start, taskSize, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
                MPI_Send(imageG_copy + start, taskSize, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
                MPI_Send(imageB_copy + start, taskSize, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
            }
        }
    }

    //write output
    if (rank == 0)
    {
        //write the output to file
        writeOutput();
    }

    //free the memory
    if (pixelSize == 1)
    {
        free(imageBW); free(imageBW_copy);
    }
    if (pixelSize == 3)
    {
        free(imageR); free(imageR_copy);
        free(imageG); free(imageG_copy);
        free(imageB); free(imageB_copy);
    }

    // if(rank == 0){
    //     inputName = "in-emboss.pnm";
    //     parseInput();
    // }

    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Finalize();
    return 0;
}
