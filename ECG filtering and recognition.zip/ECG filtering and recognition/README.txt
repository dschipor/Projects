                                                                                                  
,------.,--.,--.,--------.,------. ,--. ,--.        ,------. ,-----. ,----.    
|  .---'|  ||  |'--.  .--'|  .--. '|  | |  |        |  .---''  .--./'  .-./    
|  `--, |  ||  |   |  |   |  '--'.'|  | |  |        |  `--, |  |    |  | .---. 
|  |`   |  ||  '--.|  |   |  |\  \ '  '-'  '        |  `---.'  '--'\'  '--'  | 
`--'    `--'`-----'`--'   `--' '--' `-----'         `------' `-----' `------'  
                                                                              
																			  
!! LA FOLDERUL PERSON_74 LIPSEAU INTRARILE DIN REC_2M.MAT, ASA CA LE-AM COPIAT !!
					PE CELE DIN PERSON_01, REC_1M.MAT	


	EXERCITIUL 1:
		explicatii in comentarii
		
	
	EXERCITIUL 2:
		1.se vor descompune semnalele in sume de semnale armonice cu fft;
		2.se vor extrage in 2 vectori cele mai relevante (dupa amplitudini) 4 semnale, cu:
			
			function [A w] = make_arrays(P,f)
			
			A - vector amplitudini relevante;
			w - vector pulsatii aferente;
			
			P - vector amplitudini semnale;
			f - vector frecvente semnale;
		
		3.se va parcurge baza de date, si se va tine minte persoana pentru care distanta euclidiana
		  este minima, atat pentru amplitudine, cat si pentru frecventa (aici ar trebui sa fie 0)
		  
		  DISTANCE_A = sqrt(sum((A_INPUT - A_IDX) .^ 2));
		  DISTANCE_W = sqrt(sum((W_INPUT - W_IDX) .^ 2));
		  
	EXERCITIUL 3: (59/90) baza 1; (4/90) baza 2
		se repeta pasii de la exercitiul 2, cu mentiunea ca daca is_raw = 0, semnalul se filtreaza
		
		!!FILTRU INITIAL!!
		
		initial am incercat sa filtrez cu convolutie cu o functie de forma 
		
		h = A * exp((-1) * k * t);
		
		am facut un program cu for-uri care sa le caute, insa nu am gasit(in timp util), 2
		valori care sa dea un filtru cu acuratete buna pe teste
		
		!!FILTRU ALES!!
		
		1)am netezit semnalul raw folosind deter 
		2)am folosit in filtru de tip BANDPASS, cu valori
		
		fcuthigh = 0.67; %frecventa pentru highpass
        fcutlow = 40; %frecventa pentru lowpass
		
		valorile au fost luate de pe http://www.medteq.info/med/ECGFilters
		
		3)functia de transfer pentru filtru a fost generata folosind BUTTER
		(nu am matlab 2018, cel care are toolbox-ul pentru procesare de semnale)
		
		[b,a] = butter(order,[fcuthigh fcutlow]/(Fs/2), 'bandpass');
		
		b,a = parametri functie de transfer
		Fs = sample frequency = 500
		order = un parametru de ordine despre care nu am gasit mai nimic,
				asa ca l-am iterat 1:10(valori intalnite in exemple) si m-am uitat la acuratete;
		
		
		input_filtered = filter(b,a,input);
		(ar trebui sa fie echivalent cu conv(h,input) pentru h
		 originalul lui H(s) = B(s) / A(s)) 
					